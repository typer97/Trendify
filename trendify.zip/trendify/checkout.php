<?php
include('db.php');
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}
$user_id = $_SESSION['user_id'];
$orders = mysqli_query($conn, "SELECT * FROM orders WHERE user_id='$user_id' AND id NOT IN (SELECT order_id FROM order_details WHERE quantity = 0)");
?>
<h2>Checkout</h2>
<?php while ($order = mysqli_fetch_assoc($orders)): ?>
    <h3>Order ID: <?php echo $order['id']; ?></h3>
    <form method="post" action="process_payment.php">
        <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
        <button type="submit">Checkout</button>
    </form>
<?php endwhile; ?>