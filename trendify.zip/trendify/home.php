<?php
include('db.php');
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}
$user_id = $_SESSION['user_id'];
$products_sql = "SELECT * FROM products";
$products_result = mysqli_query($conn, $products_sql);
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    $product_id = intval($_POST['product_id']);
    $quantity = intval($_POST['quantity']);
    $cart_sql = "SELECT * FROM carts WHERE user_id = $user_id";
    $cart_result = mysqli_query($conn, $cart_sql);

    if (mysqli_num_rows($cart_result) === 0) {
        $create_cart_sql = "INSERT INTO carts (user_id) VALUES ($user_id)";
        mysqli_query($conn, $create_cart_sql);
        $cart_id = mysqli_insert_id($conn);
    } else {
        $cart = mysqli_fetch_assoc($cart_result);
        $cart_id = $cart['id'];
    }
    $check_cart_item_sql = "SELECT * FROM cart_items WHERE cart_id = $cart_id AND product_id = $product_id";
    $check_cart_item_result = mysqli_query($conn, $check_cart_item_sql);

    if (mysqli_num_rows($check_cart_item_result) > 0) {
        $update_quantity_sql = "UPDATE cart_items SET quantity = quantity + $quantity WHERE cart_id = $cart_id AND product_id = $product_id";
        mysqli_query($conn, $update_quantity_sql);
    } else {
        $add_to_cart_sql = "INSERT INTO cart_items (cart_id, product_id, quantity) VALUES ($cart_id, $product_id, $quantity)";
        mysqli_query($conn, $add_to_cart_sql);
    }
    header('Location: home.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trendify - Home</title>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body>
    <header class="navbar">
        <h1>Trendify</h1>
        <nav>
            <a href="home.php">Home</a>
            <a href="view_cart.php" class="">
                <img src="" alt="">
                View Cart
            </a>
            <a href="logout.php" class="logout-button">Logout</a>
        </nav>
    </header>
    <main>
        <h2>🆃🆁🅴🅽🅳🅸🅵🆈</h2>
        <div class="product-list">
            <?php while ($product = mysqli_fetch_assoc($products_result)): ?>
                <div class="product-item">
                    <img src="images/<?php echo htmlspecialchars($product['image'], ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($product['name'], ENT_QUOTES, 'UTF-8'); ?>">
                    <h2><?php echo htmlspecialchars($product['name'], ENT_QUOTES, 'UTF-8'); ?></h2>
                    <p><?php echo htmlspecialchars($product['description'], ENT_QUOTES, 'UTF-8'); ?></p>
                    <p>Price: $<?php echo htmlspecialchars($product['price'], ENT_QUOTES, 'UTF-8'); ?></p>
                    <form method="post" action="home.php">
                        <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                        <input type="number" name="quantity" min="1" value="1" required>
                        <button type="submit" name="add_to_cart">Add to Cart</button>
                    </form>
                </div>
            <?php endwhile; ?>
        </div>
    </main>
</body>
</html>