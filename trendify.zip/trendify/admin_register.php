<?php
include('db.php');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $email = $_POST['email'];
    $sql = "INSERT INTO users (username, password, email, user_type) VALUES ('$username', '$password', '$email', 'admin')";
    if (mysqli_query($conn, $sql)) {
        echo "Admin registration successful!";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
<form method="post" action="">
    <input type="text" name="username" placeholder="Username" required>
    <input type="password" name="password" placeholder="Password" required>
    <input type="email" name="email" placeholder="Email" required>
    <button type="submit">Register</button>
</form>