<?php
include('db.php');
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}
if (isset($_GET['order_id'])) {
    $order_id = intval($_GET['order_id']);
    $order_sql = "SELECT * FROM orders WHERE id = $order_id AND user_id = " . $_SESSION['user_id'];
    $order_result = mysqli_query($conn, $order_sql);
    $order = mysqli_fetch_assoc($order_result);
    $order_items_sql = "SELECT od.*, p.name, p.price FROM order_details od JOIN products p ON od.product_id = p.id WHERE od.order_id = $order_id";
    $order_items_result = mysqli_query($conn, $order_items_sql);
} else {
    header('Location: view_cart.php');
    exit();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $payment_method = $_POST['payment_method'];
    $payment_status = 'completed';
    $update_order_sql = "UPDATE orders SET status = '$payment_status' WHERE id = $order_id";
    mysqli_query($conn, $update_order_sql);
    header('Location: thank_you.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
    <title>Trendify - Process Payment</title>
</head>
<body>
<h1>Process Payment</h1>
<h2>Order #<?php echo htmlspecialchars($order['id'], ENT_QUOTES, 'UTF-8'); ?></h2>
<?php if (mysqli_num_rows($order_items_result) > 0): ?>
    <table>
        <thead>
            <tr>
                <th>Product</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $total_amount = 0;
            while ($item = mysqli_fetch_assoc($order_items_result)):
                $total_price = $item['price'] * $item['quantity'];
                $total_amount += $total_price;
            ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['name'], ENT_QUOTES, 'UTF-8'); ?></td>
                    <td>$<?php echo htmlspecialchars($item['price'], ENT_QUOTES, 'UTF-8'); ?></td>
                    <td><?php echo htmlspecialchars($item['quantity'], ENT_QUOTES, 'UTF-8'); ?></td>
                    <td>$<?php echo number_format($total_price, 2); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="3">Total Amount</td>
                <td>$<?php echo number_format($total_amount, 2); ?></td>
            </tr>
        </tfoot>
    </table>
    <form method="post" action="process_payment.php?order_id=<?php echo $order_id; ?>" class="payment-form">
        <label for="payment_method">Select Payment Method:</label>
        <select name="payment_method" id="payment_method">
            <option value="credit_card">Credit Card</option>
            <option value="paypal">PayPal</option>
            <option value="bank_transfer">Bank Transfer</option>
        </select>
        <button type="submit">Pay Now</button>
    </form>
<?php else: ?>
    <p>No items to display.</p>
<?php endif; ?>
</body>
</html>