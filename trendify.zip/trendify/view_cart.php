<?php
include('db.php');
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}
$user_id = $_SESSION['user_id'];
$cart_sql = "SELECT * FROM carts WHERE user_id = $user_id";
$cart_result = mysqli_query($conn, $cart_sql);
if (mysqli_num_rows($cart_result) === 0) {
    $create_cart_sql = "INSERT INTO carts (user_id) VALUES ($user_id)";
    mysqli_query($conn, $create_cart_sql);
    $cart_id = mysqli_insert_id($conn);
} else {
    $cart = mysqli_fetch_assoc($cart_result);
    $cart_id = $cart['id'];
}
$cart_items_sql = "SELECT ci.*, p.name, p.price FROM cart_items ci JOIN products p ON ci.product_id = p.id WHERE ci.cart_id = $cart_id";
$cart_items_result = mysqli_query($conn, $cart_items_sql);
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['checkout'])) {
    $order_sql = "INSERT INTO orders (user_id, status) VALUES ($user_id, 'pending')";
    mysqli_query($conn, $order_sql);
    $order_id = mysqli_insert_id($conn);
    while ($item = mysqli_fetch_assoc($cart_items_result)) {
        $product_id = $item['product_id'];
        $quantity = $item['quantity'];
        $order_details_sql = "INSERT INTO order_details (order_id, product_id, quantity) VALUES ($order_id, $product_id, $quantity)";
        mysqli_query($conn, $order_details_sql);
    }
    $clear_cart_sql = "DELETE FROM cart_items WHERE cart_id = $cart_id";
    mysqli_query($conn, $clear_cart_sql);
    header("Location: process_payment.php?order_id=$order_id");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
    <title>Trendify - View Cart</title>
</head>
<body>
<h1>Your Cart</h1>
<?php if (mysqli_num_rows($cart_items_result) > 0): ?>
    <table>
        <thead>
            <tr>
                <th>Product</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php
            mysqli_data_seek($cart_items_result, 0); // Reset result pointer
            $total_amount = 0;
            while ($item = mysqli_fetch_assoc($cart_items_result)):
                $total_price = $item['price'] * $item['quantity'];
                $total_amount += $total_price;
            ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['name'], ENT_QUOTES, 'UTF-8'); ?></td>
                    <td>$<?php echo htmlspecialchars($item['price'], ENT_QUOTES, 'UTF-8'); ?></td>
                    <td><?php echo htmlspecialchars($item['quantity'], ENT_QUOTES, 'UTF-8'); ?></td>
                    <td>$<?php echo number_format($total_price, 2); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="3">Total Amount</td>
                <td>$<?php echo number_format($total_amount, 2); ?></td>
            </tr>
        </tfoot>
    </table>
    <form method="post" action="view_cart.php" class="checkout-form">
        <button type="submit" name="checkout">Proceed to Checkout</button>
    </form>
<?php else: ?>
    <p>Your cart is empty.</p>
<?php endif; ?>
</body>
</html>