<?php
include('db.php');
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$orders = mysqli_query($conn, "SELECT * FROM orders WHERE user_id='$user_id'");

?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body>
<h2>Your Orders</h2>
<?php while ($order = mysqli_fetch_assoc($orders)): ?>
    <h3>Order ID: <?php echo $order['id']; ?></h3>
    <p>Order Date: <?php echo $order['order_date']; ?></p>
    <p>Status: <?php echo $order['status']; ?></p>
    <ul>
    <?php
    $order_details = mysqli_query($conn, "SELECT order_details.id as order_detail_id, products.*, order_details.quantity FROM order_details JOIN products ON order_details.product_id = products.id WHERE order_details.order_id = " . $order['id']);
    while ($detail = mysqli_fetch_assoc($order_details)):
    ?>
        <li>
            <?php echo $detail['name']; ?> - Quantity: <?php echo $detail['quantity']; ?>
            <?php if ($order['status'] === 'pending'): ?>
                <form method="post" action="remove_from_cart.php" style="display:inline;">
                    <input type="hidden" name="order_detail_id" value="<?php echo $detail['order_detail_id']; ?>">
                    <button type="submit" name="remove_from_cart">Remove</button>
                </form>
            <?php endif; ?>
        </li>
    <?php endwhile; ?>
    </ul>
<?php endwhile; ?>
</body>
</html>
