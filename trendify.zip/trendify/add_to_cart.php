<?php
include('db.php');
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}
if (isset($_POST['add_to_cart'])) {
    $product_id = intval($_POST['product_id']);
    $user_id = $_SESSION['user_id'];
    $check_cart_sql = "SELECT * FROM order_details 
    JOIN orders ON order_details.order_id = orders.id 
    WHERE orders.user_id = $user_id AND orders.status = 'pending' AND order_details.product_id = $product_id";
    $result = mysqli_query($conn, $check_cart_sql);
    if (mysqli_num_rows($result) > 0) {
        $update_cart_sql = "UPDATE order_details 
        SET quantity = quantity + 1 
        WHERE order_id = (SELECT id FROM orders WHERE user_id = $user_id AND status = 'pending') AND product_id = $product_id";
        mysqli_query($conn, $update_cart_sql);
    } else {
        $get_order_sql = "SELECT id FROM orders WHERE user_id = $user_id AND status = 'pending'";
        $order_result = mysqli_query($conn, $get_order_sql);
        $order = mysqli_fetch_assoc($order_result);
        $order_id = $order['id'];
        if (!$order_id) {
            $create_order_sql = "INSERT INTO orders (user_id, status) VALUES ($user_id, 'pending')";
            mysqli_query($conn, $create_order_sql);
            $order_id = mysqli_insert_id($conn);
        }
        $add_to_cart_sql = "INSERT INTO order_details (order_id, product_id, quantity) VALUES ($order_id, $product_id, 1)";
        mysqli_query($conn, $add_to_cart_sql);
    }
    header('Location: home.php');
}