<?php
include('../db.php');
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../admin_login.php');
    exit();
}
$id = $_GET['id'];
$product = mysqli_query($conn, "SELECT * FROM products WHERE id='$id'");
$product = mysqli_fetch_assoc($product);
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_product'])) {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $image = $_FILES['image']['name'];
    $target = '../images/' . basename($image);
    if ($image) {
        move_uploaded_file($_FILES['image']['tmp_name'], $target);
        $image_query = ", image='$image'";
    } else {
        $image_query = '';
    }
    $sql = "UPDATE products SET name='$name', description='$description', price='$price' $image_query WHERE id='$id'";
    mysqli_query($conn, $sql);

    header('Location: manage_products.php');
}
?>
<form method="post" enctype="multipart/form-data">
    <input type="text" name="name" value="<?php echo $product['name']; ?>" required>
    <textarea name="description" required><?php echo $product['description']; ?></textarea>
    <input type="number" name="price" value="<?php echo $product['price']; ?>" step="0.01" required>
    <input type="file" name="image">
    <button type="submit" name="update_product">Update Product</button>
</form>