<?php
include('../db.php');
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../admin_login.php');
    exit();
}
$products = mysqli_query($conn, "SELECT * FROM products");
?>
<h1>Manage Products</h1>
<?php while ($product = mysqli_fetch_assoc($products)): ?>
    <div class="product">
        <img src="../images/<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>">
        <h3><?php echo $product['name']; ?></h3>
        <p><?php echo $product['description']; ?></p>
        <p>$<?php echo $product['price']; ?></p>
        <a href="edit_product.php?id=<?php echo $product['id']; ?>">Edit</a>
        <a href="delete_product.php?id=<?php echo $product['id']; ?>">Delete</a>
    </div>
<?php endwhile; ?>