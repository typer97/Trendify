<?php
include('../db.php');
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../admin_login.php');
    exit();
}
$id = $_GET['id'];
mysqli_query($conn, "DELETE FROM products WHERE id='$id'");
header('Location: manage_products.php');
?>