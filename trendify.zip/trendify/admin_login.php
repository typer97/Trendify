<?php
include('db.php');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $sql = "SELECT * FROM users WHERE username='$username' AND user_type='admin'";
    $result = mysqli_query($conn, $sql);
    $admin = mysqli_fetch_assoc($result);
    if ($admin && password_verify($password, $admin['password'])) {
        session_start();
        $_SESSION['user_id'] = $admin['id'];
        $_SESSION['user_type'] = $admin['user_type'];
        header('Location: admin_dashboard.php');
    } else {
        echo "Invalid admin credentials!";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body>
<form method="post" action="">
    <input type="text" name="username" placeholder="Username" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit">Admin Login</button>
</form>
</body>
</html>