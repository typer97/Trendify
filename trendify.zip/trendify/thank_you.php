<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
    <title>Trendify - Thank You</title>
</head>
<body>
<h1>Thank You for Your Purchase!</h1>
<p>Your payment was successful. Your order will be processed soon.</p>
<a href="home.php">Back to Home</a>
</body>
</html>