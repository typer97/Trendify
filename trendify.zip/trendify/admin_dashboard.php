<?php
include('db.php');
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: admin_login.php');
    exit();
}
$products = mysqli_query($conn, "SELECT * FROM products");
?>
<h1>Admin Dashboard</h1>
<a href="admin/add_product.php">Add New Product</a>
<a href="admin/manage_products.php">Manage Products</a>
<h2>Products</h2>
<?php while ($product = mysqli_fetch_assoc($products)): ?>
    <div class="product">
        <img src="images/<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>">
        <h3><?php echo $product['name']; ?></h3>
        <p><?php echo $product['description']; ?></p>
        <p>$<?php echo $product['price']; ?></p>
    </div>
<?php endwhile; ?>